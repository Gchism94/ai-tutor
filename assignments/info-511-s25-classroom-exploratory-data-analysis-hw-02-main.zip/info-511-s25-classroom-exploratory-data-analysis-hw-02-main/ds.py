# HW-02: Data Analysis and Cleaning

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Task 1: Load and Inspect a Dataset
# Question: Write a function to load a dataset into a pandas DataFrame.
# - Verify that the DataFrame loads successfully.
# - Handle errors gracefully if the file is missing or unreadable.
def load_csv(file_path):
    """
    Loads a CSV file into a pandas DataFrame.

    Parameters:
    file_path (str): The path to the CSV file.

    Returns:
    pd.DataFrame: The loaded DataFrame.
    """
    pass  # Replace this with your implementation

# Task 2: Check Data Quality
# Question: Write a function to return a summary of the dataset, including:
# - Number of rows and columns.
# - Percentage of missing values per column.
# - Data types of each column.
def data_summary(df):
    """
    Provides a summary of the dataset.

    Parameters:
    df (pd.DataFrame): The DataFrame to summarize.

    Returns:
    dict: A dictionary with summary statistics, including:
        - 'shape': Tuple of rows and columns.
        - 'missing_percentage': Percentage of missing values for each column.
        - 'data_types': Data types of each column.
    """
    pass  # Replace this with your implementation


# Task 3: Clean Missing Data
# Question: Write a function to clean missing data by:
# - Replacing missing numeric values with the column mean.
# - Replacing missing non-numeric values with the most frequent value in the column.
def clean_missing_data(df):
    """
    Cleans missing data in the DataFrame.

    Parameters:
    df (pd.DataFrame): The DataFrame with missing values.

    Returns:
    pd.DataFrame: The cleaned DataFrame.
    """
    for col in df.select_dtypes(include=[np.number]):
        df[col].fillna(df[col].mean(), inplace=True)
    for col in df.select_dtypes(include=['object']):
        df[col].fillna(df[col].mode()[0], inplace=True)
    return df


# Task 4: Check for Outliers
# Question: Write a function to detect outliers in a numeric column using the IQR method.
# - Return a DataFrame of rows containing outliers.
# - Question: Why is the IQR method commonly used for detecting outliers?
def detect_outliers(df, column):
    """
    Detects outliers in a numeric column using the IQR method.

    Parameters:
    df (pd.DataFrame): The DataFrame to check for outliers.
    column (str): The column to analyze.

    Returns:
    pd.DataFrame: A DataFrame containing rows with outliers.
    """
    pass  # Replace this with your implementation


# Task 5: Visualize Numeric Columns
# Question: Write a function to visualize a numeric column as a histogram.
# - Include labels for the x-axis, y-axis, and a title.
def visualize_column(df, column, title="Column Distribution"):
    """
    Creates a histogram to visualize the distribution of a numeric column.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the column.
    column (str): The column to visualize.
    title (str): The title of the plot.

    Returns:
    None
    """
    pass  # Replace this with your implementation
