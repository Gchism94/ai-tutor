"""
Unit tests for the ds.py module.
Tests cover data loading, merging, cleaning, feature engineering,
data preparation, machine learning, and evaluation.
"""

import unittest
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from ds import (
    load_csv,
    merge_datasets,
    clean_data,
    create_feature,
    prepare_data,
    train_model,
    evaluate_model,
)


class TestDataIntegrationAndML(unittest.TestCase):
    """
    Unit tests for data integration and machine learning functions.
    """

    def setUp(self):
        """
        Load test datasets for use in all tests.
        """
        self.gapminder_path = "/mnt/data/gapminder.csv"
        self.parasites_path = "/mnt/data/parasites.csv"

        # Test data
        self.gapminder_df = load_csv(self.gapminder_path)
        self.parasites_df = load_csv(self.parasites_path)

    def test_load_csv(self):
        """
        Test load_csv function to ensure datasets load correctly.
        """
        self.assertIsInstance(self.gapminder_df, pd.DataFrame)
        self.assertIsInstance(self.parasites_df, pd.DataFrame)
        self.assertGreater(len(self.gapminder_df), 0)
        self.assertGreater(len(self.parasites_df), 0)

    def test_merge_datasets(self):
        """
        Test merge_datasets function to ensure datasets merge correctly.
        """
        merged_df = merge_datasets(self.gapminder_df, self.parasites_df, key="country")
        self.assertIsInstance(merged_df, pd.DataFrame)
        self.assertGreater(len(merged_df), 0)
        self.assertIn("country", merged_df.columns)

    def test_clean_data(self):
        """
        Test clean_data function to ensure missing values are removed.
        """
        merged_df = merge_datasets(self.gapminder_df, self.parasites_df, key="country")
        cleaned_df = clean_data(merged_df)
        self.assertFalse(cleaned_df.isnull().values.any())
        self.assertGreater(len(cleaned_df), 0)

    def test_create_feature(self):
        """
        Test create_feature function to ensure new features are correctly calculated.
        """
        merged_df = merge_datasets(self.gapminder_df, self.parasites_df, key="country")
        feature_df = create_feature(merged_df, "gdpPercap", "pop", "gdp_per_million")
        self.assertIn("gdp_per_million", feature_df.columns)
        self.assertTrue((feature_df["gdp_per_million"] >= 0).all())

    def test_prepare_data(self):
        """
        Test prepare_data function to ensure data splits correctly.
        """
        merged_df = merge_datasets(self.gapminder_df, self.parasites_df, key="country")
        cleaned_df = clean_data(merged_df)
        feature_df = create_feature(cleaned_df, "gdpPercap", "pop", "gdp_per_million")
        feature_df["target_column"] = 1  # Dummy target column for testing
        x_train, x_test, y_train, y_test = prepare_data(feature_df, target_col="target_column")
        self.assertEqual(len(x_train) + len(x_test), len(feature_df))
        self.assertEqual(len(y_train) + len(y_test), len(feature_df))

    def test_train_model(self):
        """
        Test train_model function to ensure a model is trained correctly.
        """
        merged_df = merge_datasets(self.gapminder_df, self.parasites_df, key="country")
        cleaned_df = clean_data(merged_df)
        feature_df = create_feature(cleaned_df, "gdpPercap", "pop", "gdp_per_million")
        feature_df["target_column"] = 1  # Dummy target column for testing
        x_train, _, y_train, _ = prepare_data(feature_df, target_col="target_column")
        model = train_model(x_train, y_train)
        self.assertIsInstance(model, RandomForestClassifier)

    def test_evaluate_model(self):
        """
        Test evaluate_model function to ensure evaluation metrics are generated correctly.
        """
        merged_df = merge_datasets(self.gapminder_df, self.parasites_df, key="country")
        cleaned_df = clean_data(merged_df)
        feature_df = create_feature(cleaned_df, "gdpPercap", "pop", "gdp_per_million")
        feature_df["target_column"] = 1  # Dummy target column for testing
        x_train, x_test, y_train, y_test = prepare_data(feature_df, target_col="target_column")
        model = train_model(x_train, y_train)
        evaluation = evaluate_model(model, x_test, y_test)
        self.assertIn("accuracy", evaluation)
        self.assertIn("report", evaluation)
        self.assertIsInstance(evaluation["accuracy"], float)
        self.assertIsInstance(evaluation["report"], str)


if __name__ == "__main__":
    unittest.main()
