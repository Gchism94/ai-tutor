# HW-06: Data Integration and Machine Learning

## Objectives

The learning objectives of this assignment are to:
1. Integrate multiple datasets using data joining techniques.
2. Perform data cleaning and feature engineering to prepare data for analysis.
3. Train and evaluate a machine learning model to predict outcomes based on real-world data.

## Setup Your Environment

Before starting, set up a Python environment. You will need to install the following tools and libraries:

- [Python (version 3.8 or higher)](https://www.python.org/downloads/)
- [pip](https://pip.pypa.io/en/stable/installation/)
- [pandas](https://pandas.pydata.org/)
- [scikit-learn](https://scikit-learn.org/stable/)
- [pylint](https://pylint.pycqa.org/)

### Installing Dependencies

Install the required dependencies with:
```bash
pip install -r requirements.txt
```

## Check out the starter code

When you accepted the assignment, GitHub created a clone of the assignment
template for you at:

```
https://github.com/INFO-511-S25/machine-learning-<your-username>
```

It also set up a separate `feedback` branch and a
[feedback pull request](https://docs.github.com/en/education/manage-coursework-with-github-classroom/teach-with-github-classroom/leave-feedback-with-pull-requests)
that will allow the instructional team to give you feedback on your work.

**Note that Codespaces are enabled**:
To use a Codespace, click the green Code button, select the Codespaces tab, then Create codespace on main. 

**Alternatively, you can use your local machine**:
To get the assignment code on your local machine, clone the repository:
```bash
git clone https://github.com/INFO-511-S25/machine-learning-<your-username>.git
```
You are now ready to begin working on the assignment.
You should do all your work in the default branch, `main`.

## File Descriptions

### `ds.py`
This is the main file where you will write your implementations. The file contains the following functions to complete:

1. **`load_csv(file_path)`**:
   - Load a dataset from a CSV file into a pandas DataFrame.
   - Print the first few rows for inspection.
2. **`merge_datasets(df1, df2, key)`**:
   - Merge two datasets based on a common column.
3. **`clean_data(df)`**:
   - Remove rows with missing values from the dataset.
4. **`create_feature(df, gdp_col, pop_col, new_col_name)`**:
   - Create a new feature (e.g., GDP per million) using existing columns.
5. **`prepare_data(df, target_col, test_size, random_state)`**:
   - Split the dataset into training and testing sets.
6. **`train_model(X_train, y_train)`**:
   - Train a Random Forest Classifier on the training data.
7. **`evaluate_model(model, X_test, y_test)`**:
   - Evaluate the trained model using accuracy and a classification report.

### `test_ds.py`
This file contains automated tests for the functions in `ds.py`. Do not modify this file. It will verify the correctness of your implementation.

### `requirements.txt`
Lists the required Python packages for this assignment.

### Datasets
- **`gapminder.csv`**:
  - Contains demographic and economic data, such as GDP per capita and population size.
  - Columns include:
    - `country`: Country name.
    - `gdpPercap`: GDP per capita.
    - `pop`: Population size.
- **`parasites.csv`**:
  - Contains health-related data, including the presence of parasites.
  - Columns include:
    - `country`: Country name.
    - `target_column`: Binary target variable (e.g., presence of parasites).
- **`births14.csv`**:
  - Additional dataset for potential feature engineering or exploratory analysis.

## Instructions

1. Open `ds.py` and implement the functions according to the docstrings provided.
2. Do **not** modify any other files.
3. Test your implementation by running the test suite.

## Running Tests

To verify your implementation, run the tests using `unittest`:
```bash
python -m unittest test_ds.py
```

- Initially, the tests will fail because no implementation exists.
- Once your code is correct, all tests will pass.

Example output when all tests pass:
```plaintext
============================= test session starts ==============================
...
collected 7 items

test_ds.py .......                                                [100%]

============================== 7 passed in 0.15s ===============================
```

### Additional Checks

Ensure your code adheres to Python's coding standards by running `pylint`:
```bash
pylint ds.py
```

A perfect score looks like:
```plaintext
--------------------------------------------------------------------
Your code has been rated at 10.00/10 (previous run: 10.00/10, +0.00)
```

## Submission Instructions

1. Commit your changes to `ds.py`:
   ```bash
   git add ds.py
   git commit -m "Implemented functions for HW-06"
   git push
   ```

2. Do **not** modify or merge the `test_ds.py` file or other files.

3. Ensure your tests pass on GitHub by checking the CI/CD results.

## Grading

### Points Allocation
- **80 points** for passing all automated correctness (`unittest`) tests.
- **10 points** for passing all automated quality (`pylint`) checks.
- **10 points** for overall code quality, including:
  - Using appropriate data structures.
  - Avoiding code duplication.
  - Giving variables meaningful names.
  - Documenting complex logic.

### Deductions
- Lose **5 points** for:
  - Modifying files other than `ds.py`.
  - Merging the "Feedback" pull request on GitHub.
  - Deleting or editing docstrings in `ds.py`.

Good luck, and happy coding!
