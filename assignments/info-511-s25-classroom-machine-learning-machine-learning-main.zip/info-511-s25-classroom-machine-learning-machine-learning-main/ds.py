# HW-06: Data Integration and Machine Learning

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

# Task 1: Load and Inspect Datasets
# Question: Write a function to load datasets from CSV files into pandas DataFrames.
# - Ensure all files load correctly.
def load_csv(file_path):
    """
    Loads a CSV file into a pandas DataFrame.

    Parameters:
    file_path (str): The path to the CSV file.

    Returns:
    pd.DataFrame: The loaded DataFrame.
    """
    try:
        df = pd.read_csv(file_path)
        print(f"Data loaded successfully from {file_path}.")
        print(df.head())  # Display first 5 rows for inspection
        return df
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"An error occurred while loading the file: {e}")
    return None


# Task 2: Merge Datasets
# Question: Write a function to merge `gapminder.csv` and `parasites.csv` on a common column.
def merge_datasets(df1, df2, key):
    """
    Merges two DataFrames on a specified key.

    Parameters:
    df1 (pd.DataFrame): The first DataFrame.
    df2 (pd.DataFrame): The second DataFrame.
    key (str): The column to merge on.

    Returns:
    pd.DataFrame: The merged DataFrame.
    """
    return pd.merge(df1, df2, on=key)


# Task 3: Clean Data
# Question: Write a function to clean the merged dataset by dropping rows with missing values.
def clean_data(df):
    """
    Cleans the DataFrame by removing rows with missing values.

    Parameters:
    df (pd.DataFrame): The DataFrame to clean.

    Returns:
    pd.DataFrame: The cleaned DataFrame.
    """
    return df.dropna()


# Task 4: Feature Engineering
# Question: Write a function to create a new feature based on the `gapminder.csv` data.
# - Example: Calculate GDP per capita as `gdpPercap` * `pop` / 1e6.
def create_feature(df, gdp_col, pop_col, new_col_name):
    """
    Creates a new feature in the DataFrame.

    Parameters:
    df (pd.DataFrame): The DataFrame to modify.
    gdp_col (str): The column representing GDP per capita.
    pop_col (str): The column representing population.
    new_col_name (str): The name of the new column.

    Returns:
    pd.DataFrame: The modified DataFrame with the new column.
    """
    df[new_col_name] = df[gdp_col] * df[pop_col] / 1e6
    return df


# Task 5: Prepare Data for Machine Learning
# Question: Write a function to prepare data for machine learning by splitting it into train and test sets.
def prepare_data(df, target_col, test_size=0.2, random_state=42):
    """
    Prepares data for machine learning by splitting into train and test sets.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    target_col (str): The target column for predictions.
    test_size (float): The proportion of data to include in the test set.
    random_state (int): The random seed for reproducibility.

    Returns:
    tuple: x_train, x_test, y_train, y_test
    """
    X = df.drop(columns=[target_col])
    y = df[target_col]
    return train_test_split(X, y, test_size=test_size, random_state=random_state)


# Task 6: Train a Machine Learning Model
# Question: Write a function to train a Random Forest Classifier on the training data.
def train_model(x_train, y_train):
    """
    Trains a Random Forest Classifier.

    Parameters:
    x_train (pd.DataFrame): The training features.
    y_train (pd.Series): The training labels.

    Returns:
    RandomForestClassifier: The trained model.
    """
    model = RandomForestClassifier(random_state=42)
    model.fit(x_train, y_train)
    return model


# Task 7: Evaluate the Model
# Question: Write a function to evaluate the trained model using accuracy and a classification report.
def evaluate_model(model, x_test, y_test):
    """
    Evaluates the trained model.

    Parameters:
    model (RandomForestClassifier): The trained model.
    x_test (pd.DataFrame): The test features.
    y_test (pd.Series): The test labels.

    Returns:
    dict: A dictionary containing the accuracy score and classification report.
    """
    y_pred = model.predict(x_test)
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)
    return {"accuracy": accuracy, "report": report}