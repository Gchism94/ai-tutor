# midterm

## Instructions

This summative assignment will showcase your learning up to the first half of INFO 511. 

**Find the full directions at the following [LINK](https://datasciaz.netlify.app/summative/midterm.html)**
