---
name: 'Midterm Grading '
about: 'Feedback '
title: 'Midterm Feedback '
labels: ''
assignees: ''

---

---
name: Feedback
about: Feedback for assignment
title: Feedback
labels: ''
assignees: ''

---

Dear [STUDENT GITHUB NAME] -- Below is the feedback for your assignment. Please review carefully, and stop by office hours if you have any questions about the feedback.

---

## Rubric

The midterm assignment is graded out of a total of 100 points.

## Feedback

Here's the updated GitHub issue markdown using the grading schema I provided:

### Question 1:

- Score: `[_ / 10 points]`
- Feedback: [Insert feedback here.]

### Question 2:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 3:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 4:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 5:

- Score: `[_ / 10 points]`
- Feedback: [Insert feedback here.]

### Question 6:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 7:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 8:

- Score: `[_ / 10 points]`
- Feedback: [Insert feedback here.]

### Question 9:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 10:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 11:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 12:

- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 13:

- Score: `[_ / 10 points]`
- Feedback: [Insert feedback here.]

### Question 14:
- Total: `[_ / 10 points]`

#### Part 1
- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

#### Part 2
- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Question 15:
- Total: `[_ / 10 points]`

#### Part 1
- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

#### Part 2
- Score: `[_ / 5 points]`
- Feedback: [Insert feedback here.]

### Overall: `[_ / 100 points]`

- Feedback: [Insert feedback here.]

## Late penalty

- [ ] On time: No penalty
- [ ] Late, within 24-hours: -10 points
- [ ] Late, between 24-48-hours: -20 points