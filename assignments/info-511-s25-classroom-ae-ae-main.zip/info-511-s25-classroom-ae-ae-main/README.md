# ae

Application Exercises for INFO 511 F'24 - Fundamentals of Data Science - taught by Dr. Greg Chism

## Directions

You must complete 80% of the applcation exercises by the end of the semester (Sunday December 08, 11:59pm)
