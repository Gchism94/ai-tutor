# Objectives

The learning objectives of this assignment are to:
1. Apply data science and machine learning techniques to a community task.
2. Develop models to predict outcomes on real-world datasets.
3. Practice hyper-parameter tuning and model evaluation.

# Read about the CodaBench Competition

You will be participating in a class-wide competition.  
The competition website is:

[https://www.codabench.org/competitions/6813/?secret_key=d147b095-0fde-4709-a898-f648c27bbe3a](https://www.codabench.org/competitions/6813/?secret_key=d147b095-0fde-4709-a898-f648c27bbe3a)

You should visit that site and read all the details of the competition, including:
- Task definitions.
- How your models will be evaluated.
- Format of submissions to the competition.

# Create a CodaBench Account

To participate in the competition, follow these steps:
1. Visit the competition website.
2. Click the "Sign Up" button in the upper-right corner of the page and create an account.
   **Please use your @arizona.edu email when signing up.**
   Your username will appear publicly on the leaderboard, but your email will remain private.
   If you wish to remain anonymous, choose a username that does not reveal your identity.
3. After creating an account, click the "My Submissions" tab, accept the terms and conditions, and register for the competition.
4. Wait for your instructor to approve your registration. Approval may take a few days.
5. Once approved, you will see a "Submission upload" form under the "My Submissions" tab. This confirms your registration is complete.

# Clone the Repository

Clone the GitHub repository created by GitHub Classroom to your local machine:
```bash
git clone https://github.com/INFO-511-S25/final-project-<your-username>.git
```
You are now ready to begin working on the assignment.

# Download the Data

1. Visit the "Get Started" tab on the CodaBench competition site and navigate to the "Files" sub-tab.
2. Download and unzip the training and development data into your cloned repository directory.
   **Please do not commit the data to your repository.**
3. When the test phase begins, return to the "Files" sub-tab to download the unlabeled test dataset.

# Write Your Code

You will design machine learning models to solve the tasks described on the CodaBench site.  
Your models should:
- Train on the provided training data.
- Tune hyper-parameters using the development data.
- Generate predictions for either the development or test datasets.

Use the provided baseline code as a starting point. This repository contains a Python script template that you can modify or extend. You are free to delete the baseline code and start from scratch if preferred.

# Evaluate Your Models

During the **development phase**, upload your predictions on the development set to the competition site.  
This will:
1. Allow you to test your model's performance.
2. Ensure that your submission format is correct.

You can submit predictions multiple times during the development phase, so it’s recommended to test your code after significant changes.

If you encounter issues with submissions on CodaBench (e.g., a submission gets stuck), cancel it and try again. Refer to the [CodaBench documentation](https://github.com/codalab/codabench/issues/1184) for more information.

# Test Your Model Predictions

When the **test phase** begins:
1. Download the unlabeled test dataset from the competition site.
2. Run your model on the test dataset and generate predictions.
3. Upload your predictions as a `submission.zip` file to the "My Submissions" tab of the CodaBench site.

**Important:** You may submit predictions only once during the test phase. Debug your formatting during the development phase to avoid issues.

# Grading

Your grade will be based on:
1. Your model's performance on the test dataset.
2. Your rank on the competition leaderboard.

Grading criteria:
- Models achieving better accuracy than the provided baseline will receive at least a B.
- Models outperforming a higher baseline (revealed after the competition) will receive an A.
- Rankings within each letter grade will determine percentage scores (e.g., top-ranked A gets 100%, lowest-ranked A gets 90%).

**Restrictions:**
- If you use external libraries or datasets beyond the provided materials, you must request permission in the course's Slack workspace. Unauthorized use will result in a 10% grade penalty.
