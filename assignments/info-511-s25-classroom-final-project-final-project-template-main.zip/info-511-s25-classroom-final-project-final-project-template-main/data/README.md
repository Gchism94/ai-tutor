## Data

For all data in one `.zip`, download via [CyVerse](https://data.cyverse.org/dav-anon/iplant/home/gchism/courses/info511/final_project_health/data.zip)
