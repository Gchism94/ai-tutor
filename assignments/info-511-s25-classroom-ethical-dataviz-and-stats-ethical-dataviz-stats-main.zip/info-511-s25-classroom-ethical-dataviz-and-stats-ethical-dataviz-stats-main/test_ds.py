"""
Unit tests for ethical data analysis functions in ds.py.

This module contains tests for the following functions:
- load_csv
- summarize_data
- check_demographic_bias
- scatter_plot
- assess_visualization_practices
- compare_means
- box_plot
- anonymize_column
"""

import unittest
import pandas as pd
import numpy as np
from ds import (
    load_csv,
    summarize_data,
    check_demographic_bias,
    scatter_plot,
    assess_visualization_practices,
    compare_means,
    box_plot,
    anonymize_column,
)


class TestEthicalDataAnalysis(unittest.TestCase):
    """Test suite for ethical data analysis functions."""

    def setUp(self):
        """Set up test datasets for all test cases."""
        self.datasaurus_path = "data/datasaurus_dozen.csv"
        self.survation_path = "data/survation.csv"

        self.datasaurus_df = load_csv(self.datasaurus_path)
        self.survation_df = load_csv(self.survation_path)

    def test_load_csv(self):
        """Test the load_csv function."""
        self.assertIsInstance(self.datasaurus_df, pd.DataFrame)
        self.assertGreater(len(self.datasaurus_df), 0)
        self.assertIsInstance(self.survation_df, pd.DataFrame)
        self.assertGreater(len(self.survation_df), 0)

    def test_summarize_data(self):
        """Test the summarize_data function."""
        summary = summarize_data(self.datasaurus_df)
        self.assertIsInstance(summary, pd.DataFrame)
        self.assertIn("mean", summary.columns)
        self.assertIn("median", summary.columns)
        self.assertIn("variance", summary.columns)
        self.assertIn("std", summary.columns)

    def test_check_demographic_bias(self):
        """Test the check_demographic_bias function."""
        bias = check_demographic_bias(self.datasaurus_df, "x", "dataset")
        self.assertIsInstance(bias, pd.DataFrame)
        self.assertTrue(np.all((bias >= 0) & (bias <= 1)))

    def test_scatter_plot(self):
        """Test the scatter_plot function."""
        try:
            scatter_plot(
                self.datasaurus_df,
                "x",
                "y",
                hue="dataset",
                title="Datasaurus Relationships",
            )
        except ValueError as err:
            self.fail(f"scatter_plot raised an exception: {err}")


    def test_assess_visualization_practices(self):
        """Test the assess_visualization_practices function."""
        is_fair = assess_visualization_practices(self.datasaurus_df, "x", "y")
        self.assertIsInstance(is_fair, bool)

    def test_compare_means(self):
        """Test the compare_means function."""
        t_stat, p_val = compare_means(self.survation_df, "Age", "Vote", "Conservative", "Labour")
        self.assertIsInstance(t_stat, float)
        self.assertIsInstance(p_val, float)

    def test_box_plot(self):
        """Test the box_plot function."""
        try:
            box_plot(self.survation_df, "Vote", "Age", title="Age Distribution by Vote")
        except ValueError as err:
            self.fail(f"box_plot raised an exception: {err}")

    def test_anonymize_column(self):
        """Test the anonymize_column function."""
        anonymized_df = anonymize_column(self.survation_df, "Name")
        self.assertIn("Name", anonymized_df.columns)
        name_dtype = anonymized_df["Name"].dtype
        self.assertTrue(np.issubdtype(name_dtype, np.number))

    def test_missing_file(self):
        """Test the load_csv function with a missing file."""
        missing_df = load_csv("non_existent_file.csv")
        self.assertIsNone(missing_df)


if __name__ == "__main__":
    unittest.main()
