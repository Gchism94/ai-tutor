# HW-04: Ethical Data Visualization and Statistical Analysis

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats

# Task 1: Load a Dataset
# Question: Write a function to load a dataset from a CSV file into a pandas DataFrame.
# - Ensure the file loads correctly.
# - Include error handling for missing or invalid files.
def load_csv(file_path):
    """
    Loads a CSV file into a pandas DataFrame.

    Parameters:
    file_path (str): The path to the CSV file.

    Returns:
    pd.DataFrame: The loaded DataFrame.
    """
    try:
        df = pd.read_csv(file_path)
        print(f"Data loaded successfully from {file_path}.")
        print(df.head())  # Display the first 5 rows for inspection
        return df
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"An error occurred while loading the file: {e}")
    return None


# Task 2: Summarize Data
# Question: Write a function to compute summary statistics for a dataset.
# - Return the mean, median, variance, and standard deviation for numeric columns.
def summarize_data(df):
    """
    Computes summary statistics for numeric columns in the DataFrame.

    Parameters:
    df (pd.DataFrame): The DataFrame to summarize.

    Returns:
    pd.DataFrame: A DataFrame with summary statistics.
    """
    summary = df.describe().transpose()
    summary["variance"] = df.var()
    return summary[["mean", "50%", "variance", "std"]].rename(columns={"50%": "median"})


# Task 3: Identify Bias
# Question: Analyze whether any groups are over- or under-represented in the dataset.
def check_demographic_bias(df, column, group_col):
    """
    Checks for demographic bias by calculating group proportions.

    Parameters:
    df (pd.DataFrame): The DataFrame to analyze.
    column (str): The column representing the demographic (e.g., 'Age').
    group_col (str): The column representing the group (e.g., 'Vote').

    Returns:
    pd.DataFrame: A DataFrame with proportions of each group within each demographic category.
    """
    return df.groupby(group_col)[column].value_counts(normalize=True).unstack()


# Task 4: Visualize Relationships
# Question: Write a function to visualize the relationship between two numeric columns.
# - Use a scatterplot with the option to color by a categorical column.
def scatter_plot(df, x_col, y_col, hue=None, title="Scatter Plot"):
    """
    Creates a scatterplot to visualize the relationship between two columns.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    x_col (str): The column to use for the x-axis.
    y_col (str): The column to use for the y-axis.
    hue (str, optional): The column to use for color coding.
    title (str): The title of the plot.

    Returns:
    None
    """
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=df, x=x_col, y=y_col, hue=hue, palette="viridis")
    plt.title(title)
    plt.show()


# Task 5: Ethical Visualization
# Question: Evaluate whether visualizations fairly represent the data.
def assess_visualization_practices(df, x_col, y_col):
    """
    Evaluates whether the data supports fair visualization practices.

    Parameters:
    df (pd.DataFrame): The DataFrame to analyze.
    x_col (str): The column used for the x-axis.
    y_col (str): The column used for the y-axis.

    Returns:
    bool: True if visualizations are likely ethical, False otherwise.
    """
    range_x = df[x_col].max() - df[x_col].min()
    range_y = df[y_col].max() - df[y_col].min()

    if range_x == 0 or range_y == 0:
        return False  # Indicates potentially problematic visual representation
    return True


# Task 6: Compare Groups
# Question: Write a function to compare the means of a numeric column between two groups.
# - Use an independent t-test and return the t-statistic and p-value.
def compare_means(df, col, group_col, group1, group2):
    """
    Compares the means of a numeric column between two groups using a t-test.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    col (str): The numeric column to compare.
    group_col (str): The column containing group labels.
    group1 (str): The first group to compare.
    group2 (str): The second group to compare.

    Returns:
    tuple: A tuple containing the t-statistic and p-value.
    """
    group1_data = df[df[group_col] == group1][col]
    group2_data = df[df[group_col] == group2][col]
    t_stat, p_val = stats.ttest_ind(group1_data, group2_data, equal_var=False)
    return t_stat, p_val


# Task 7: Visualize Group Comparisons
# Question: Write a function to create a boxplot comparing the distribution of a numeric column across groups.
def box_plot(df, x_col, y_col, title="Box Plot"):
    """
    Creates a boxplot to visualize group comparisons.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    x_col (str): The column to use for the x-axis (categorical).
    y_col (str): The column to use for the y-axis (numeric).
    title (str): The title of the plot.

    Returns:
    None
    """
    plt.figure(figsize=(8, 6))
    sns.boxplot(data=df, x=x_col, y=y_col, palette="viridis")
    plt.title(title)
    plt.show()


# Task 8: Privacy Considerations
# Question: Write a function to anonymize sensitive data in a dataset.
def anonymize_column(df, column):
    """
    Anonymizes a column by replacing its values with unique identifiers.

    Parameters:
    df (pd.DataFrame): The DataFrame to modify.
    column (str): The column to anonymize.

    Returns:
    pd.DataFrame: The modified DataFrame with the anonymized column.
    """
    df[column] = pd.factorize(df[column])[0]
    return df

