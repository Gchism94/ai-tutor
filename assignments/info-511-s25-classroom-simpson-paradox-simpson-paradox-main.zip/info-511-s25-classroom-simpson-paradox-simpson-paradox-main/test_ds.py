"""
Unit tests for the ds.py module.
Tests include functionality for loading data, summarizing data, analyzing
relationships, and visualizing results.
"""

import unittest
import pandas as pd
import numpy as np
from ds import (
    load_csv,
    summarize_categorical,
    compute_disease_prevalence,
    plot_disease_prevalence,
    perform_chi_squared_test,
    analyze_relationship,
)

class TestEducationDiseaseAnalysis(unittest.TestCase):
    """
    Unit tests for education and disease analysis.
    """

    def setUp(self):
        """
        Load the test dataset for all test cases.
        """
        self.dataset_path = "data/education-disease.csv"
        self.df = load_csv(self.dataset_path)

    def test_load_csv(self):
        """
        Test the load_csv function to ensure the dataset is loaded correctly.
        """
        self.assertIsInstance(self.df, pd.DataFrame)
        self.assertGreater(len(self.df), 0)
        self.assertIn("education", self.df.columns)
        self.assertIn("TenYearCHD", self.df.columns)

    def test_summarize_categorical(self):
        """
        Test summarize_categorical to ensure frequency counts are accurate.
        """
        education_summary = summarize_categorical(self.df, "education")
        self.assertIsInstance(education_summary, pd.Series)
        self.assertGreater(len(education_summary), 0)

    def test_compute_disease_prevalence(self):
        """
        Test compute_disease_prevalence to ensure correct prevalence calculations.
        """
        prevalence_df = compute_disease_prevalence(self.df, "education", "TenYearCHD")
        self.assertIsInstance(prevalence_df, pd.DataFrame)
        self.assertIn("education", prevalence_df.columns)
        self.assertIn("TenYearCHD", prevalence_df.columns)
        self.assertGreater(len(prevalence_df), 0)
        self.assertTrue(np.all((prevalence_df["TenYearCHD"] >= 0) &
                               (prevalence_df["TenYearCHD"] <= 1)))

    def test_plot_disease_prevalence(self):
        """
        Ensure plot_disease_prevalence runs without error.
        """
        try:
            plot_disease_prevalence(self.df, "education", "TenYearCHD")
        except Exception as e:
            self.fail(f"plot_disease_prevalence raised an exception: {e}")

    def test_perform_chi_squared_test(self):
        """
        Test perform_chi_squared_test to ensure valid chi-squared statistics are returned.
        """
        chi2, p, dof = perform_chi_squared_test(self.df, "education", "TenYearCHD")
        self.assertIsInstance(chi2, float)
        self.assertIsInstance(p, float)
        self.assertIsInstance(dof, int)
        self.assertGreaterEqual(p, 0)
        self.assertLessEqual(p, 1)

    def test_analyze_relationship(self):
        """
        Test analyze_relationship to ensure accurate summary statistics for numerical columns.
        """
        age_analysis = analyze_relationship(self.df, "age", "TenYearCHD")
        self.assertIsInstance(age_analysis, pd.DataFrame)
        self.assertIn("Age Mean", age_analysis.columns)
        self.assertIn("Age Std", age_analysis.columns)
        self.assertGreater(len(age_analysis), 0)

    def test_missing_file(self):
        """
        Test load_csv with an invalid file path to ensure it handles errors gracefully.
        """
        missing_df = load_csv("non_existent_file.csv")
        self.assertIsNone(missing_df)


if __name__ == "__main__":
    unittest.main()
