# HW-04: Exploring Relationships Between Education and Disease

## Objectives

The learning objectives of this assignment are to:
1. Develop proficiency in Python for exploring relationships between categorical and numerical variables.
2. Understand and analyze the prevalence of diseases (e.g., TenYearCHD) across different education levels.
3. Visualize data insights effectively and perform statistical analyses to evaluate associations.

## Setup Your Environment

Before starting, set up a Python environment. You will need to install the following tools and libraries:

- [Python (version 3.8 or higher)](https://www.python.org/downloads/)
- [pip](https://pip.pypa.io/en/stable/installation/)
- [pandas](https://pandas.pydata.org/)
- [numpy](https://numpy.org/)
- [matplotlib](https://matplotlib.org/)
- [seaborn](https://seaborn.pydata.org/)
- [scipy](https://scipy.org/)
- [pylint](https://pylint.pycqa.org/)

### Installing Dependencies

Install the required dependencies with:
```bash
pip install -r requirements.txt
```

## Check out the starter code

When you accepted the assignment, GitHub created a clone of the assignment
template for you at:

```
https://github.com/INFO-511-S25/simpson-paradox-<your-username>
```

It also set up a separate `feedback` branch and a
[feedback pull request](https://docs.github.com/en/education/manage-coursework-with-github-classroom/teach-with-github-classroom/leave-feedback-with-pull-requests)
that will allow the instructional team to give you feedback on your work.

**Note that Codespaces are enabled**:
To use a Codespace, click the green Code button, select the Codespaces tab, then Create codespace on main. 

**Alternatively, you can use your local machine**:
To get the assignment code on your local machine, clone the repository:
```bash
git clone https://github.com/INFO-511-S25/simpson-paradox-<your-username>.git
```
You are now ready to begin working on the assignment.
You should do all your work in the default branch, `main`.

## File Descriptions

### `ds.py`
This is the main file where you will write your implementations. The file contains the following functions to complete:

1. **`load_csv(file_path)`**:
   - Load a dataset from a CSV file into a pandas DataFrame.
   - Inspect the dataset's structure and print basic details.
2. **`summarize_categorical(df, column)`**:
   - Compute frequency counts for a specified categorical column.
3. **`compute_disease_prevalence(df, education_col, disease_col)`**:
   - Calculate the prevalence of the disease (`TenYearCHD`) across education levels.
4. **`plot_disease_prevalence(df, education_col, prevalence_col, title)`**:
   - Create a bar plot visualizing disease prevalence across education levels.
5. **`perform_chi_squared_test(df, education_col, disease_col)`**:
   - Perform a chi-squared test to evaluate the association between education levels and disease prevalence.
6. **`analyze_relationship(df, numerical_col, disease_col)`**:
   - Analyze the relationship between a numerical variable (e.g., age) and disease prevalence using group-level statistics.

### `test_ds.py`
This file contains automated tests for the functions in `ds.py`. Do not modify this file. It will verify the correctness of your implementation.

### `requirements.txt`
Lists the required Python packages for this assignment.

### Dataset
- **`education-disease.csv`**:
   - A dataset containing demographic, educational, and health-related information.
   - Key columns:
     - `Education`: Categorical variable representing education levels.
     - `TenYearCHD`: Binary variable indicating the presence of a ten-year risk for coronary heart disease.
     - `Age`: Numerical variable representing age.
     - Additional columns for further analysis (e.g., BMI).

## Instructions

1. Open `ds.py` and implement the functions according to the docstrings provided.
2. Do **not** modify any other files.
3. Test your implementation by running the test suite.

## Running Tests

To verify your implementation, run the tests using `unittest`:
```bash
python -m unittest test_ds.py
```

- Initially, the tests will fail because no implementation exists.
- Once your code is correct, all tests will pass.

Example output when all tests pass:
```plaintext
============================= test session starts ==============================
...
collected 7 items

test_ds.py .......                                                [100%]

============================== 7 passed in 0.12s ===============================
```

### Additional Checks

Ensure your code adheres to Python's coding standards by running `pylint`:
```bash
pylint ds.py
```

A perfect score looks like:
```plaintext
--------------------------------------------------------------------
Your code has been rated at 10.00/10 (previous run: 10.00/10, +0.00)
```

## Submission Instructions

1. Commit your changes to `ds.py`:
   ```bash
   git add ds.py
   git commit -m "Implemented functions for HW-05"
   git push
   ```

2. Do **not** modify or merge the `test_ds.py` file or other files.

3. Ensure your tests pass on GitHub by checking the CI/CD results.

## Grading

### Points Allocation
- **80 points** for passing all automated correctness (`unittest`) tests.
- **10 points** for passing all automated quality (`pylint`) checks.
- **10 points** for overall code quality, including:
  - Using appropriate data structures.
  - Avoiding code duplication.
  - Giving variables meaningful names.
  - Documenting complex logic.

### Deductions
- Lose **5 points** for:
  - Modifying files other than `ds.py`.
  - Merging the "Feedback" pull request on GitHub.
  - Deleting or editing docstrings in `ds.py`.

Good luck, and happy coding!
