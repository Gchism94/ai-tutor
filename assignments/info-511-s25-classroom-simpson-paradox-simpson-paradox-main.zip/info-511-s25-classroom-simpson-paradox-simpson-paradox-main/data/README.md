# Metadata

### `education-disease.csv`

1. `male`: Indicator variable for gender (1 = male, 0 = female).
2. `age`: Age of the individual in years.
3. `education`: Level of education (categorical, represented as numbers; e.g., 1 = less than high school, 2 = high school, 3 = some college or covational school, 4 = college graduate).
4. `currentSmoker`: Indicator variable for current smoking status (1 = current smoker, 0 = non-smoker).
5. `cigsPerDay`: Average number of cigarettes smoked per day.
6. `BPMeds`: Indicator variable for whether the individual is on blood pressure medication (1 = yes, 0 = no).
7. `prevalentStroke`: Indicator variable for history of stroke (1 = history of stroke, 0 = no history).
8. `prevalentHyp`: Indicator variable for prevalent hypertension (1 = hypertension, 0 = no hypertension).
9. `diabetes`: Indicator variable for diabetes (1 = diabetic, 0 = non-diabetic).
10. `totChol`: Total cholesterol level (mg/dL).
11. `sysBP`: Systolic blood pressure (mmHg).
12. `diaBP`: Diastolic blood pressure (mmHg).
13. `BMI`: Body Mass Index (calculated as weight in kg divided by the square of height in meters).
14. `heartRate`: Heart rate (beats per minute).
15. `glucose`: Glucose level (mg/dL).
16. `TenYearCHD`: KEY Indicator variable for 10-year risk of coronary heart disease (1 = likely, 0 = unlikely). THIS IS THE VARIABLE TO USE FOR DISEASE PREVALENCE
