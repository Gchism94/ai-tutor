# HW-04: Exploring Relationships Between Education and Disease

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats

# Task 1: Load and Inspect the Dataset
def load_csv(file_path):
    """
    Loads a CSV file into a pandas DataFrame.

    Parameters:
    file_path (str): The path to the CSV file.

    Returns:
    pd.DataFrame: The loaded DataFrame.
    """
    # TODO: Load the CSV file and display basic info
    pass


# Task 2: Summarize Categorical Variables
def summarize_categorical(df, column):
    """
    Summarizes a categorical column by computing frequency counts.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    column (str): The categorical column to summarize.

    Returns:
    pd.Series: A Series with frequency counts for each category.
    """
    # TODO: Compute value counts
    pass


# Task 3: Compare Disease Prevalence Across Education Levels
def compute_disease_prevalence(df, education_col, disease_col):
    """
    Computes the prevalence of a disease for each education level.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    education_col (str): The column representing education levels.
    disease_col (str): The column representing disease status.

    Returns:
    pd.DataFrame: A DataFrame with education levels and corresponding disease prevalence.
    """
    # TODO: Group by education level and calculate mean disease prevalence
    pass


# Task 4: Visualize Disease Prevalence
def plot_disease_prevalence(df, education_col, prevalence_col, title="Disease Prevalence by Education Level"):
    """
    Creates a bar plot to visualize disease prevalence across education levels.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    education_col (str): The column representing education levels.
    prevalence_col (str): The column representing disease prevalence.
    title (str): The title of the plot.

    Returns:
    None
    """
    # TODO: Create a seaborn bar plot
    pass


# Task 5: Statistical Analysis of Disease Prevalence
def perform_chi_squared_test(df, education_col, disease_col):
    """
    Performs a chi-squared test for independence between education levels and disease prevalence.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    education_col (str): The column representing education levels.
    disease_col (str): The column representing disease status.

    Returns:
    tuple: A tuple containing the chi-squared statistic, p-value, and degrees of freedom.
    """
    # TODO: Create a contingency table and perform chi-squared test
    pass


# Task 6: Analyze Relationships with Additional Variables
def analyze_relationship(df, numerical_col, disease_col):
    """
    Analyzes the relationship between a numerical variable and disease prevalence.

    Parameters:
    df (pd.DataFrame): The DataFrame containing the data.
    numerical_col (str): The numerical column to analyze.
    disease_col (str): The column representing disease status.

    Returns:
    dict: A dictionary with the mean and standard deviation of the numerical column for each disease status.
    """
    # TODO: Group by disease status and compute mean and standard deviation
    pass
