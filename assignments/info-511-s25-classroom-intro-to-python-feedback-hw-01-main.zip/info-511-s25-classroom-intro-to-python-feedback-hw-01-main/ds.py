# Homework 1: Introduction to Python
# Complete all tasks as specified. You should implement each function below
# and ensure it meets the requirements described in the docstrings.

# Task 1: Compute the mean of a list of numbers.
def compute_mean(numbers):
    """
    Computes the mean of a list of numbers.

    Parameters:
    numbers (list): A list of numerical values.

    Returns:
    float: The mean of the numbers in the list, or None if the list is empty.
    """
    pass  # Replace this with your implementation


# Task 2: Compute the median of a list of numbers.
def compute_median(numbers):
    """
    Computes the median of a list of numbers.

    Parameters:
    numbers (list): A list of numerical values.

    Returns:
    float: The median of the numbers in the list, or None if the list is empty.
    """
    pass  # Replace this with your implementation


# Task 3: Compute the mode of a list of numbers.
def compute_mode(numbers):
    """
    Computes the mode of a list of numbers.

    Parameters:
    numbers (list): A list of numerical values.

    Returns:
    int/float: The mode of the numbers in the list, or None if the list is empty.
    """
    pass  # Replace this with your implementation


# Task 4: Handle edge cases for each function.
def test_edge_cases():
    """
    Tests the compute_mean, compute_median, and compute_mode functions on edge cases.

    Cases to test:
    1. Empty list.
    2. List with one number.
    3. List with negative numbers.
    4. List with repeating numbers.
    """
    test_data = {
        "empty": [],
        "single": [42],
        "negative": [-5, -10, -15],
        "repeating": [1, 2, 2, 3, 3, 3, 4],
    }

    # Testing compute_mean
    print("Testing compute_mean...")
    for case, data in test_data.items():
        print(f"{case} case: Input: {data}, Mean: {compute_mean(data)}")

    # Testing compute_median
    print("\nTesting compute_median...")
    for case, data in test_data.items():
        print(f"{case} case: Input: {data}, Median: {compute_median(data)}")

    # Testing compute_mode
    print("\nTesting compute_mode...")
    for case, data in test_data.items():
        print(f"{case} case: Input: {data}, Mode: {compute_mode(data)}")


# Task 5: Implement a custom function to calculate the range of a list of numbers.
def compute_range(numbers):
    """
    Computes the range (difference between max and min) of a list of numbers.

    Parameters:
    numbers (list): A list of numerical values.

    Returns:
    float: The range of the numbers in the list, or None if the list is empty.
    """
    pass  # Replace this with your implementation


# Task 6: Write a function to test all implemented calculations.
def test_calculations():
    """
    Tests compute_mean, compute_median, compute_mode, and compute_range 
    with predefined datasets and prints the results.
    """
    datasets = [
        [1, 2, 3, 4, 5],
        [10, 20, 30, 40, 50],
        [-1, 0, 1, 2, 3],
        [3, 3, 3, 4, 4, 5, 5],
    ]

    print("Testing all functions with datasets...\n")
    for data in datasets:
        print(f"Dataset: {data}")
        print(f"Mean: {compute_mean(data)}")
        print(f"Median: {compute_median(data)}")
        print(f"Mode: {compute_mode(data)}")
        print(f"Range: {compute_range(data)}")
        print("-" * 30)


# Uncomment the following lines to run the test functions.
# test_edge_cases()
# test_calculations()
