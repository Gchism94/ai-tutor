"""
Unit tests for data transformation functions in the assignment.

This module contains tests for the following functions:
- load_csv
- rename_columns
- merge_datasets
- filter_high_inflation
- group_and_aggregate_inflation
- plot_inflation_by_division
- save_csv
"""

import unittest
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from ds import (
    load_csv,
    rename_columns,
    merge_datasets,
    filter_high_inflation,
    group_and_aggregate_inflation,
    plot_inflation_by_division,
    save_csv,
)

class TestDataTransformation(unittest.TestCase):
    """Test suite for data transformation functions."""

    def setUp(self):
        """Set up test datasets for all test cases."""
        self.us_inflation_df = pd.DataFrame({
            "cpi_division_id": [1, 2, 3],
            "year": [2020, 2021, 2022],
            "inflation_rate": [1.2, 2.3, 3.4],
        })

        self.cpi_divisions_df = pd.DataFrame({
            "cpi_division": [1, 2, 3],
            "description": ["Food", "Energy", "Housing"],
        })

    def test_load_csv(self):
        """Test the load_csv function with a missing file."""
        missing_df = load_csv("non_existent_file.csv")
        self.assertIsNone(missing_df)

    def test_rename_columns(self):
        """Test renaming columns in a DataFrame."""
        rename_dict = {"inflation_rate": "cpi"}
        renamed_df = rename_columns(self.us_inflation_df, rename_dict)
        self.assertIn("cpi", renamed_df.columns)
        self.assertNotIn("inflation_rate", renamed_df.columns)

    def test_merge_datasets(self):
        """Test merging datasets."""
        merged_df = merge_datasets(self.us_inflation_df, self.cpi_divisions_df)
        self.assertIn("description", merged_df.columns)
        self.assertIn("inflation_rate", merged_df.columns)
        self.assertIn("year", merged_df.columns)

    def test_filter_high_inflation(self):
        """Test filtering high inflation rates."""
        filtered_df = filter_high_inflation(self.us_inflation_df, "inflation_rate", 2.0)
        self.assertTrue((filtered_df["inflation_rate"] > 2.0).all())

    def test_group_and_aggregate_inflation(self):
        """Test grouping and aggregating inflation rates."""
        grouped_df = group_and_aggregate_inflation(self.us_inflation_df, "cpi_division_id", "inflation_rate", "mean")
        self.assertIn("cpi_division_id", grouped_df.columns)
        self.assertTrue(np.issubdtype(grouped_df["inflation_rate"].dtype, np.number))

    def test_plot_inflation_by_division(self):
        """Test that the plotting function runs without error and creates a figure."""
        plt.figure()  # Ensure a clean figure
        try:
            plot_inflation_by_division(self.us_inflation_df, "cpi_division_id", "inflation_rate")
            self.assertGreater(len(plt.gcf().get_axes()), 0)  # Check that axes were created
        except Exception as e:
            self.fail(f"plot_inflation_by_division raised an exception: {e}")
        finally:
            plt.close()

    def test_save_csv(self):
        """Test saving DataFrame to a CSV file."""
        test_df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})
        save_csv(test_df, "test_output.csv")
        loaded_df = pd.read_csv("test_output.csv")
        pd.testing.assert_frame_equal(test_df, loaded_df)

if __name__ == "__main__":
    unittest.main()
